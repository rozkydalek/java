/* CIS107-6 Programming for Applications
 * First In-Class Test (AY2020-21 Block 3)
 *
 * Question 2
 * You are required to write a Java program 
 * to convert from 10 kilometres to miles 
 * and from 100 miles to kilometres. 
 * Please note: 1 mile is 1.609 kilometres 
 * and 1 kilometre is 0.621 miles. 
 * Your program should be able to display 
 * the results on the console window. 
 * Variables must be declared and used 
 * to represent the values of miles 
 * and kilometres respectively. 
 * You are required to use proper comments 
 * to explain your program, including your 
 * surname and student ID number as comments. (30 Marks) 
 */


/*******************************************************************************
 * @author  Michal Rozkydalek 
 * @student 1932198
 * @version 0.00.0000 — 2021-02-19
 */
public class Question2 
{
    double distance1km = 10.0;  // distance 1 in kilometres
    double distance2mi = 100.0; // distance 2 in miles
      
    public static double convKmToMi(double a) //kilometres to miles conversion method
    {
      double kmtomi = 1.609; // km to miles conversion multiplier
      double conversion = a * kmtomi; // conversion to miles
      return conversion; // method to return converted result
    }
    
    public static double convMiToKm(double a) //miles to kilometres conversion method
    {
      double mitokm = 0.621; // miles to km conversion multiplier
      double conversion = a * mitokm; // conversion to kilometres
      return conversion; // method to return converted result
    }    
    
    public static void main() // a no-return main procedure for printout
    {
    Question2 myResult2 = new Question2(); 
    double distance1mi = convMiToKm(myResult2.distance1km);
    System.out.print("The distance of " + myResult2.distance1km + " kilometres converts to ");
    System.out.println(distance1mi + " miles.");    
    
    double distance2km = convKmToMi(myResult2.distance2mi);
    System.out.print("The distance of " + myResult2.distance2mi + " miles converts to ");
    System.out.println(distance2km + " kilometres.");    
    
    }
}
