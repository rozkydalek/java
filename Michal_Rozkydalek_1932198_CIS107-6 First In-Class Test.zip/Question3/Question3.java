/* CIS107-6 Programming for Applications
 * First In-Class Test (AY2020-21 Block 3)
 *
 * Question 3
 * 
 * You are required to write a Java program 
 * to calculate the total area of the shaded parts 
 * of the figure given below. 
 * The shaded area contains four identical rectangles. 
 * The Area of each shaded rectangle can be calculated 
 * using the following equation: 
 *
 *   A = x * y
 *
 *  A represents the area of a rectangle, and x and y represent 
 *  two different length sides of a rectangle. The values of x and y 
 *  for the shaded rectangle have been given in the figure. 
 *  You are required to create two methods in your program. 
 *  
 *  The first method computes the area of a shaded rectangle. 
 *  The method should have two parameters in order to pass given data 
 *  into the computation and should have a return value. 
 *  
 *  The second method is the main() method that invokes the first method 
 *  iteratively (i.e. must use a loop) to add up the total area of the 
 *  shaded 4 rectangles. 
 *  
 *  You should apply the “good” program structure to your codes 
 *  in order to support human readability e.g. to use indentation, 
 *  to use meaningful comments, including your surname and student ID number 
 *  as part of comments, and so on. 
 *  
 *  Your program should display the total shaded area as the result 
 *  on the console window. (50 Marks) 
 */


/*******************************************************************************
 * @author  Michal Rozkydalek 
 * @student 1932198
 * @version 0.00.0000 — 2021-02-19
 */
public class Question3 
{
    int n = 4; // amount of the identical rectangle areas to sum
    double sidex = 20.0; // the rectangle side located of the x-axis
    double sidey = 50.0;  // the rectangle side located of the y-axis
    
    public static double rectangleArea(double x,double y) // method to calculate a single rectangle area
    {
      double area = x*y; // formula to calculate a single rectangle area
      return area; // method to return the calcuated result
    }
    
    public static double sumOfAreas(int c, double a, double b) //a cycle to sum all the rectangle areas
    {
        double sumAreas = 0; // declaring an empty variable for summing of areas

            int i =1; //a counter
            for (i = 1; i <= c; i++) // a cycle to call a method for counting areas of multiple identical rectangles 
            {
                sumAreas=sumAreas+rectangleArea(a,b);
            }
            
        return sumAreas; // method to return sum of all the identical rectangles
            
    }    

    public static void main() // a no-return main procedure for printout
    {
        Question3 myResult3 = new Question3();   // creating a new object
    
        System.out.print("The sum of areas of all the " + myResult3.n + " identical rectangles amounts ");
        System.out.println(sumOfAreas(myResult3.n, myResult3.sidex, myResult3.sidey) + " square units.");    
    
    }
}
