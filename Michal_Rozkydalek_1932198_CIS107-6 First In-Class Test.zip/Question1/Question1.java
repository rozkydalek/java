/* CIS107-6 Programming for Applications
 * First In-Class Test (AY2020-21 Block 3)
 *
 * Question 1
 * You are required to write a Java program 
 * to output "Computer Science and Technology" 
 * in the same line on the console window. 
 * Words must be separated by space. 
 * You are also required to create strings 
 * using the keyword “new”. 
 * (20 Marks)
 */


/*******************************************************************************
 * @author  Michal Rozkydalek 
 * @student 1932198
 * @version 0.00.0000 — 2021-02-19
 */
public class Question1 
{
    String a = "Computer";
    String b = "Science";
    String c = "and";
    String d = "Technology";
    String e = " ";

    public static void main(String[] args)
    { 
        Question1 myResult = new Question1(); 
        {
            String output = myResult.a+myResult.e+myResult.b+myResult.e+myResult.c+myResult.e+myResult.d;
            System.out.println(output);
        }    
    }
}
